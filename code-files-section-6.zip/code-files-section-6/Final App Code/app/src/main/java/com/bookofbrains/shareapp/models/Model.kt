package com.bookofbrains.shareapp.models

data class Hobby(var title: String)

object Supplier {

	val hobbies = listOf(
			Hobby("Swimming"),
			Hobby("Reading"),
			Hobby("Squash"),
			Hobby("Running"),
			Hobby("Games"),
			Hobby("Writing"),
			Hobby("Sleeping"),
			Hobby("Swimming"),
			Hobby("Reading"),
			Hobby("Squash"),
			Hobby("Running"),
			Hobby("Games"),
			Hobby("Writing"),
			Hobby("Sleeping"),
			Hobby("Swimming"),
			Hobby("Reading"),
			Hobby("Squash"),
			Hobby("Running"),
			Hobby("Games"),
			Hobby("Writing"),
			Hobby("Sleeping"),
			Hobby("Swimming"),
			Hobby("Reading"),
			Hobby("Squash"),
			Hobby("Running"),
			Hobby("Games"),
			Hobby("Writing"),
			Hobby("Sleeping")
	)
}
