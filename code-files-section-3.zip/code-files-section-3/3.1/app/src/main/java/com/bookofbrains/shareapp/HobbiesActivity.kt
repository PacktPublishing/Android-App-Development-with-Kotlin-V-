package com.bookofbrains.shareapp

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class HobbiesActivity : AppCompatActivity() {

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.hobbies_activity)
	}

}