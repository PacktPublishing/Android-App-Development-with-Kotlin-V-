package com.bookofbrains.shareapp

object Constants {
	val USER_MESSAGE_KEY: String = "user_message"
}